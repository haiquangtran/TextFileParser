package main;
public class RobotInterruptedException extends RuntimeException{}
