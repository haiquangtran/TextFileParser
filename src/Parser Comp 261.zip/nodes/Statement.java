package nodes;

import main.ParserFailureException;
import main.RobotProgramNode;

abstract public class Statement implements RobotProgramNode{
	
	

}
